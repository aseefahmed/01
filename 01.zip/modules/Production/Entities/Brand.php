<?php namespace Modules\Production\Entities;
   
use Illuminate\Database\Eloquent\Model;

class Brand extends Model {

    protected $fillable = [];

}