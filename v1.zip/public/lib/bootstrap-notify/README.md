bootstrap-notify
================

Bootstrap alert system made better. [See Demo](http://goodybag.github.com/bootstrap-notify)

### Contributors

* Nijiko Yonskai <http://twitter.com/nijikokun>
* Lalit Kapoor <https://github.com/lalitkapoor>


Copyright 2012 Goodybag, Inc.
