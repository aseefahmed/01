<?php namespace Modules\Production\Entities;
   
use Illuminate\Database\Eloquent\Model;

class Agent extends Model {

    protected $fillable = [];

}