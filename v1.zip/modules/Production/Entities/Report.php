<?php namespace Modules\Production\Entities;
   
use Illuminate\Database\Eloquent\Model;

class Report extends Model {

    protected $fillable = [];

}