<?php namespace Modules\Production\Entities;
   
use Illuminate\Database\Eloquent\Model;

class RequisitionType extends Model {

    protected $fillable = [];

}