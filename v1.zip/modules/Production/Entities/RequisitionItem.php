<?php namespace Modules\Production\Entities;
   
use Illuminate\Database\Eloquent\Model;

class RequisitionItem extends Model {

    protected $fillable = [];

}