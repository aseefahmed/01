<?php

return [
	'name' => 'Model'
];