<?php namespace Modules\Hrm\Entities;
   
use Illuminate\Database\Eloquent\Model;

class Employee extends Model {

    protected $fillable = [];

}