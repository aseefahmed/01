<?php namespace Modules\Buying\Entities;
   
use Illuminate\Database\Eloquent\Model;

class BuyingOrder extends Model {

    protected $fillable = [];

    protected $table = 'BuyingOrder';

}