<?php

return [
	'name' => 'Buying'
];