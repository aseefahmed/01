<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class Test1Controller extends Controller
{
    public function viewDashboard()
    {
        return 'hi';
    }

}
